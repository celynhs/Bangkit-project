package com.sulton.belibijak.ui.cart

import androidx.lifecycle.ViewModel

class CartViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}