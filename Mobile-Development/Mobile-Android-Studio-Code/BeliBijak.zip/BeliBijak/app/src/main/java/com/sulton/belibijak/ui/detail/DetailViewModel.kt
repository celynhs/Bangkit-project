package com.sulton.belibijak.ui.detail

class DetailViewModel {
}