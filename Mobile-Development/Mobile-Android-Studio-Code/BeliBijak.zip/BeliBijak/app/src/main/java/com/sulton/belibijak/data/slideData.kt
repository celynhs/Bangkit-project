package com.sulton.belibijak.data

data class slideData(
    val title: String,
    val desc: String,
    val imgUrl: String
)
